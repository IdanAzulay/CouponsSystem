package ex;

@SuppressWarnings("serial")
public class customerAlreadyExistsException extends Exception {

	public customerAlreadyExistsException(String msg) {
		super(msg);
	}
}
