package ex;

@SuppressWarnings("serial")
public class companyAlreadyExistException extends Exception{
	
	public companyAlreadyExistException(String msg) {
		super(msg);
	}

}
