package ex;

@SuppressWarnings("serial")
public class zeroCouponAmountException extends Exception{
	
	public zeroCouponAmountException(String msg) {
		super(msg);
	}

}
