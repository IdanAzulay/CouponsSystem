package ex;

@SuppressWarnings("serial")
public class SystemMalfunctionException extends Exception {
	public SystemMalfunctionException(String msg) {
		super(msg);

	}
}
