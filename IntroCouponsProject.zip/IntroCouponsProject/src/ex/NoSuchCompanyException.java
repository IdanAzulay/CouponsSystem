package ex;

@SuppressWarnings("serial")
public class NoSuchCompanyException extends Exception {

	public NoSuchCompanyException(String msg) {
		super(msg);
	}
	
}
