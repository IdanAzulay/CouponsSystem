package ex;

@SuppressWarnings("serial")
public class couponAlreadyExistsException extends Exception{
	
	public couponAlreadyExistsException(String msg) {
		super(msg);
	} 

}
