import ex.CouponAllreadyPurchasedException;
import ex.CouponNotExistsException;
import ex.InvalidLoginException;
import ex.SystemMalfunctionException;
import ex.zeroCouponAmountException;
import facade.CouponSystem;
import facade.CustomerFacade;
import facade.LoginType;

public class RanyTest {

	public static void main(String[] args) throws InvalidLoginException, SystemMalfunctionException, CouponAllreadyPurchasedException, CouponNotExistsException, zeroCouponAmountException {
	
		CustomerFacade facade = (CustomerFacade) CouponSystem.getInstance().login("idan", "abc1234", LoginType.CUSTOMER);
		
		facade.purchaseCoupon(1);
		
		
		
		
	}
	}
