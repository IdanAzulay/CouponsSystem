package facade;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;

import db.CompanyDBDao;
import db.CompanyDao;
import db.CouponDAO;
import db.CouponDBDAO;
import ex.CouponNotExistsException;
import ex.InvalidLoginException;
import ex.NoSuchCompanyException;
import ex.SystemMalfunctionException;
import ex.couponAlreadyExistsException;
import model.Company;
import model.Coupon;

public class CompanyFacade extends AbsFacade {

	private CompanyDao companyDBDao;
	private CouponDAO couponDBDao;
	private Company company;

	public CompanyFacade(Company company, CompanyDao companyDao, CouponDAO couponDao) {

		this.company = company;
		this.companyDBDao = companyDao;
		this.couponDBDao = couponDao;

	}

	public static AbsFacade performLogin(String name, String password)
			throws SystemMalfunctionException, InvalidLoginException {

		CompanyDao companyDBDao = new CompanyDBDao();
		CouponDAO couponDBDao = new CouponDBDAO();

		Company company = companyDBDao.login(name, password);

		return new CompanyFacade(company, companyDBDao, couponDBDao);

	}

	public void createCoupon(Coupon coupon)
			throws SystemMalfunctionException, NoSuchCompanyException, couponAlreadyExistsException {

		Collection<Coupon> coupons = companyDBDao.getCoupons(company.getId());
		for (Coupon c : coupons) {
			if (c.getTitle().equals(coupon.getTitle())) {
				throw new couponAlreadyExistsException("Coupon with that title already exists.");
			}
		}
		couponDBDao.createCoupon(coupon, company.getId());

	}

	public void removeCoupon(long couponID) throws CouponNotExistsException {
		try {
			couponDBDao.removeCoupon(couponID);
		} catch (SystemMalfunctionException e) {
			throw new CouponNotExistsException("Invalid id : " + couponID);
		}
	}

	public void updateCoupon(Coupon coupon)
			throws couponAlreadyExistsException, CouponNotExistsException, SystemMalfunctionException {

		Coupon c = couponDBDao.getCoupon(coupon.getId());

		if (!c.getTitle().equals(coupon.getTitle())) {
			throw new couponAlreadyExistsException("Changing title is not allowed");

		}
		couponDBDao.updateCoupon(coupon);
	}

	public Coupon getCoupon(long ID) throws CouponNotExistsException {
		try {

			return couponDBDao.getCoupon(ID);
		} catch (SystemMalfunctionException e) {
			throw new CouponNotExistsException("Coupon Not exist , wrong ID " + ID);
		}
	}

	public Collection<Coupon> getAllCoupons() throws SystemMalfunctionException {
		return couponDBDao.getAllCoupons();
	}

	public Collection<Coupon> getCouponsLowerThanPrice(double price) throws SystemMalfunctionException {

		Collection<Coupon> coupons2 = new ArrayList<>();
		Collection<Coupon> coupons = couponDBDao.getAllCoupons();
		for (Coupon c : coupons) {
			if (price > c.getPrice()) {
				coupons2.add(c);
			}
		}
		if (coupons2.isEmpty()) {
			throw new SystemMalfunctionException("There are no coupons lower than price " + price);
		} else {
			return coupons2;
		}
	}

	public Collection<Coupon> getCouponsBeforeDate(LocalDate date) throws SystemMalfunctionException {
		Collection<Coupon> coupons2 = new ArrayList<>();
		Collection<Coupon> coupons = couponDBDao.getAllCoupons();
		for (Coupon c : coupons) {
			if (c.getEndDate().isBefore(date)) {
				coupons2.add(c);
			}
		}

		if (coupons2.isEmpty()) {
			throw new SystemMalfunctionException("there are no coupons before date : " + date);
		} else {
			return coupons2;

		}
	}

	public Company getCompany() {
		return company;
	}

}
