package facade;

import java.util.ArrayList;
import java.util.Collection;

import db.CouponDAO;
import db.CouponDBDAO;
import db.CustomerDBDao;
import db.CustomerDao;
import ex.CouponAllreadyPurchasedException;
import ex.CouponNotExistsException;
import ex.InvalidLoginException;
import ex.NoSuchCustomerException;
import ex.SystemMalfunctionException;
import ex.zeroCouponAmountException;
import model.Coupon;
import model.CouponCategory;
import model.Customer;

public class CustomerFacade extends AbsFacade {

	private CustomerDao customerDao;
	private CouponDAO couponDAO;
	private Customer customer;

	public CustomerFacade(CouponDAO couponDAO, CustomerDao customerDao, Customer customer) {
		this.couponDAO = couponDAO;
		this.customerDao = customerDao;
		this.customer = customer;

	}

	public static AbsFacade performLogin(String name, String password)
			throws SystemMalfunctionException, InvalidLoginException {

		CustomerDao customerDao = new CustomerDBDao();
		CouponDAO couponDAO = new CouponDBDAO();

		Customer customer = customerDao.login(name, password);

		return new CustomerFacade(couponDAO, customerDao, customer);
	}

	public void purchaseCoupon(long couponID) throws CouponAllreadyPurchasedException, CouponNotExistsException,
			zeroCouponAmountException, SystemMalfunctionException {

		Collection<Coupon> coupons = customerDao.getCoupons(customer.getId());
		for (Coupon c : coupons) {

			if (c.getId() == couponID) {
				throw new CouponAllreadyPurchasedException("Unavailble to purchase twice.");
			}
		}
		try {
			couponDAO.decrementCouponAmount(couponID);
		} catch (SystemMalfunctionException e) {
			System.out.println("Coupon out of stock.");
		}
		try {
			coupons.add(couponDAO.getCoupon(couponID));
			customerDao.insertCustomerCoupon(customer.getId(), couponID);

		} catch (SystemMalfunctionException | NoSuchCustomerException e) {
			System.out.println("Coupon id Wrong");
		}
		

	}

	public Collection<Coupon> getAllCoupons() throws SystemMalfunctionException {

		Collection<Coupon> coupons = customerDao.getCoupons(customer.getId());
		return coupons;
	}

	public Collection<Coupon> getCouponsByCategory(CouponCategory category) throws SystemMalfunctionException {

		int A = category.ordinal();
		Collection<Coupon> coupons = customerDao.getCoupons(customer.getId());
		Collection<Coupon> couponsCategory = new ArrayList<>();

		for (Coupon c : coupons) {
			if (c.getCategory() == A) {
				couponsCategory.add(c);
			}
		}

		return couponsCategory;

	}

	public Customer getCustomer() {
		return customer;
	}

	public Collection<Coupon> getCouponsLowerThanPrice(double price)
			throws SystemMalfunctionException, NoSuchCustomerException {

		Collection<Coupon> coupons = customerDao.getCoupons(customer.getId());
		Collection<Coupon> lowerThanPrice = new ArrayList<>();
		for (Coupon c : coupons) {

			if (c.getPrice() < price) {
				lowerThanPrice.add(c);
			}

		}
		return lowerThanPrice;
	}
}
