package facade;

import java.time.LocalDate;
import java.util.Collection;

import db.CouponDAO;
import db.CouponDBDAO;
import ex.CouponNotExistsException;
import ex.SystemMalfunctionException;
import model.Coupon;

public class TaskRemoveDailyCoupons implements Runnable {

	private CouponDAO dao;
	private boolean isAlive;

	private TaskRemoveDailyCoupons(CouponDAO dao) {
		this.dao = dao;
	}

	public static TaskRemoveDailyCoupons create() {
		return new TaskRemoveDailyCoupons(new CouponDBDAO());
	}

	@Override
	public void run() {
		isAlive = true;

		try {
			while (isAlive) {
				Collection<Coupon> allCoupons = dao.getAllCoupons();
				
				for (Coupon coupon : allCoupons) {
					if (coupon.getEndDate().isBefore(LocalDate.now())) {
						dao.removeCoupon(coupon.getId());
					}
				}

				Thread.sleep(1000 * 60 * 60 * 24);
			}
		} catch (SystemMalfunctionException | CouponNotExistsException | InterruptedException e) {
			// Ignore.
		}

	}

	public void stop() {
		isAlive = false;
	}

}
