package facade;

import ex.InvalidLoginException;
import ex.SystemMalfunctionException;

public class AbsFacade {

	protected static AbsFacade login(String name, String password, LoginType type)
			throws InvalidLoginException, SystemMalfunctionException {

		switch (type) {
			case ADMIN:
				return AdminFacade.performLogin(name, password);
			case COMPANY:

				return CompanyFacade.performLogin(name, password);
			case CUSTOMER:

				return CustomerFacade.performLogin(name, password);
			default:
				break;

		}
		return null;
	}
}
