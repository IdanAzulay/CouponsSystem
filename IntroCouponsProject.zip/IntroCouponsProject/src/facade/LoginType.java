package facade;

public enum LoginType {
ADMIN , COMPANY , CUSTOMER
}
