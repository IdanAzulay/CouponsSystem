package facade;

import java.util.Collection;

import db.CompanyDBDao;
import db.CompanyDao;
import db.CouponDAO;
import db.CouponDBDAO;
import db.CustomerDBDao;
import db.CustomerDao;
import ex.CouponNotExistsException;
import ex.InvalidLoginException;
import ex.NoSuchCompanyException;
import ex.NoSuchCustomerException;
import ex.SystemMalfunctionException;
import ex.companyAlreadyExistException;
import ex.customerAlreadyExistsException;
import model.Company;
import model.Coupon;
import model.Customer;

public class AdminFacade extends AbsFacade {

	private CompanyDao companyDao;
	private CustomerDao customerDao;
	private CouponDAO couponDao;

	private AdminFacade() {
		companyDao = new CompanyDBDao();
		customerDao = new CustomerDBDao();
		couponDao = new CouponDBDAO();
	}

	public static AbsFacade performLogin(String name, String password) throws InvalidLoginException {

		if ("admin".equals(name) && "1234".equals(password)) {
			return new AdminFacade();
		}
		throw new InvalidLoginException("Unable to login as Admin , Wrong name or password");
	}

	public void createCompany(Company company) throws companyAlreadyExistException, SystemMalfunctionException {

		Collection<Company> companies = companyDao.getAllCompanies();
		for (Company c : companies) {
			if (c.getName().equals(company.getName())) {
				throw new companyAlreadyExistException("Company already exist!");
			}
			
		}
		companyDao.createCompany(company);

	}
	

	public void removeCompany(long companyId) throws SystemMalfunctionException, NoSuchCompanyException {
		Collection<Coupon> coupons = companyDao.getCoupons(companyId);
		for (Coupon c : coupons) {

			try {
				couponDao.removeCoupon(c.getId());
			} catch (SystemMalfunctionException | CouponNotExistsException e) {
				// we ignore such case.
			}

		}
		companyDao.removeCompany(companyId);

	}

	public void updateCompany(Company company) throws SystemMalfunctionException, NoSuchCompanyException {

		Company c = companyDao.getCompany(company.getId());

		if (!company.getName().equals(c.getName())) {
			throw new SystemMalfunctionException("Changing company's name is not allowed.");
		}

		companyDao.updateCompany(company);
	}

	public Collection<Company> getAllCompanies() throws SystemMalfunctionException {
		return companyDao.getAllCompanies();
	}

	public Company getCompany(long companyId) throws SystemMalfunctionException, NoSuchCompanyException {
		return companyDao.getCompany(companyId);
	}

	public void createCustomer(Customer customer) throws SystemMalfunctionException {

		Collection<Customer> customers = customerDao.getAllCustomers();

		for (Customer c : customers) {
			if (c.getName().equals(customer.getName())) {
				throw new SystemMalfunctionException("Customer name already in use.");
			}
		}
			try {
				customerDao.createCustomer(customer);
			} catch (customerAlreadyExistsException e) {
				System.out.println("Customer name already in use.");
			}
		

	}

	public void removeCustomer(long id)
			throws SystemMalfunctionException, NoSuchCustomerException, CouponNotExistsException {

		Collection<Coupon> coupons = customerDao.getCoupons(id);
		for (Coupon c : coupons) {
			couponDao.removeCoupon(c.getId());
		}
		customerDao.removeCustomer(id);

	}

	public void updateCustomer(Customer customer) throws SystemMalfunctionException, NoSuchCustomerException {

		Customer c = customerDao.getCustomer(customer.getId());

		if (!customer.getName().equals(c.getName())) {
			throw new SystemMalfunctionException("Changing name is not allowed.");

		}
		customerDao.updateCustomer(customer);
	}

	public Collection<Customer> getAllCustomers() throws SystemMalfunctionException {
		return customerDao.getAllCustomers();
	}

	public Collection<Coupon> getCouponsByCustomer(Customer customer)
			throws SystemMalfunctionException, NoSuchCustomerException {
		long customerId = customer.getId();
		return customerDao.getCoupons(customerId);
	}

	public Customer getCustomer(long customerId) throws SystemMalfunctionException, NoSuchCustomerException {
		return customerDao.getCustomer(customerId);

	}

}
