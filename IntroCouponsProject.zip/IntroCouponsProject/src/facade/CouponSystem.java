package facade;

import ex.InvalidLoginException;
import ex.SystemMalfunctionException;

public class CouponSystem {

	private static CouponSystem instance;
	private TaskRemoveDailyCoupons taskRemoveDailyCoupons;
	private Thread dailyThread;
	
	private CouponSystem() {
		taskRemoveDailyCoupons = TaskRemoveDailyCoupons.create();
		dailyThread = new Thread(taskRemoveDailyCoupons);

	}

	public static CouponSystem getInstance() {
		if (instance == null) {
			instance = new CouponSystem();
		}

		return instance;
	}

	public AbsFacade login(String name, String password, LoginType type)
			throws InvalidLoginException, SystemMalfunctionException {
		return AbsFacade.login(name, password, type);
	}

	protected void start() {

		dailyThread.start();
	}

}
