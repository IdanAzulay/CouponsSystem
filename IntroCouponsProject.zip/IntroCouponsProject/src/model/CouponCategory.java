package model;

	public enum CouponCategory {
		
		TRAVELING , FOOD , ELECTRICITY , HEALTH , SPORTS , CAMPING , FASHION , STUDIES;
	}
	

