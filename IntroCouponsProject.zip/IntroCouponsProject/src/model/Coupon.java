package model;


import java.time.LocalDate;

public class Coupon {
	public static final int NO_ID = -1;

	private long id = NO_ID;
	private String title;
	private LocalDate startDate;
	private LocalDate endDate;
	private int amount;
	private int category;
	private String message;
	private double price;
	private String image;

	public Coupon() {
		this.id = NO_ID;
		this.title = "No Title";
		this.startDate = LocalDate.of(2000, 01, 01); 
		this.endDate = LocalDate.of(2000, 01, 01); 
		this.amount = 0;
		this.category = 0;
		this.message = "Empty Coupon";
		this.price = 0;
		this.image = "None";
	}
	
	
	
	
	
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getCategory() {
		return category;
	}

	public void setCategory(int category) {
		this.category = category;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "Coupon [id=" + id + ", title=" + title + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", amount=" + amount + ", category=" + category + ", message=" + message + ", price=" + price
				+ ", image=" + image + "]";
	}
	
	public static Coupon empty() {
		Coupon coupon = new Coupon();
		return coupon;
	}

}
