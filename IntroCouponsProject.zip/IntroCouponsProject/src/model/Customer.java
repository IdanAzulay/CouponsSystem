package model;


import java.util.HashSet;
import java.util.Set;

public class Customer {
	public static final int NO_ID = -1;

	private long id = NO_ID;
	private String name;
	private String password;
	// A collection that contains no duplicate elements. More formally, sets
	// contain no pair of elements e1 and e2 such that e1.equals(e2), and at
	// most one null element. As implied by its name, this interface models the
	// mathematical set abstraction.
	private Set<Coupon> coupons;

	public Customer() {
		coupons = new HashSet<>();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set<Coupon> getCoupons() {
		return coupons;
	}

	public void setCoupons(Set<Coupon> coupons) {
		this.coupons = coupons;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", password=" + password + ", coupons=" + coupons + "]";
	}
}
