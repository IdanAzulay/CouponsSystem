package db;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import common.ConnectionPool;
import common.StatementUtils;
import ex.CouponNotExistsException;
import ex.SystemMalfunctionException;
import ex.couponAlreadyExistsException;
import ex.zeroCouponAmountException;
import model.Coupon;
import model.CouponCategory;

public class CouponDBDAO implements CouponDAO {

	public CouponDBDAO() {
		try {
			createTable();
		} catch (SystemMalfunctionException e) {

			System.out.println("Should never happand!");
		}
	}

	@Override
	public void createTable() throws SystemMalfunctionException {
		Connection connection = null;
		Statement stmtCreateCouponTable = null;

		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtCreateCouponTable = connection.createStatement();
			stmtCreateCouponTable.executeUpdate(Schema.getCreateTableCoupon());

		} catch (SQLException e) {
			throw new SystemMalfunctionException("Something went wrong , Unable to create coupon table.");

		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtCreateCouponTable);
		}
	}

	@Override
	public void createCoupon(Coupon coupon, long companyID)
			throws SystemMalfunctionException, couponAlreadyExistsException {
		Collection<Coupon> coupons = getAllCoupons();
		Connection connection = null;
		PreparedStatement stmtCreateCoupon = null;
		PreparedStatement stmtInsertIntoCompanyCoupon = null;
		try {

			connection = ConnectionPool.getInstance().getConnection();
			stmtCreateCoupon = connection.prepareStatement(Schema.getInsertCoupon(), Statement.RETURN_GENERATED_KEYS);
			applyCouponValuesOnStatement(coupon, stmtCreateCoupon);
			for (Coupon c : coupons) {
				if (c.getTitle().equals(coupon.getTitle())) {
					throw new couponAlreadyExistsException("Ttitle Already in use.");

				}
			}

			stmtCreateCoupon.executeUpdate();
			long couponID = getGeneratedPrimaryKey(stmtCreateCoupon);
			stmtInsertIntoCompanyCoupon = connection.prepareStatement(Schema.getInsertCompanyCoupon());
			stmtInsertIntoCompanyCoupon.setLong(1, companyID);
			stmtInsertIntoCompanyCoupon.setLong(2, couponID);
			int rowAffected = stmtInsertIntoCompanyCoupon.executeUpdate();
			if (rowAffected == 0) {
				throw new SystemMalfunctionException(
						"Unable to add coupon to company cupon table , Invalid coupon or company id.");
			}
		} catch (

		SQLException e) {
			throw new SystemMalfunctionException("Unable to create coupon , Something went wrong." + e.getMessage());

		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtCreateCoupon);

		}

	}

	@Override
	public void removeCoupon(long couponID) throws SystemMalfunctionException, CouponNotExistsException {

		Connection connection = null;
		PreparedStatement stmtDeleteCoupon = null;

		if (couponID == Coupon.NO_ID) {
			throw new CouponNotExistsException("Unable to remove coupon , Invalid id : " + couponID);

		}
		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtDeleteCoupon = connection.prepareStatement(Schema.getDeleteCoupon());
			stmtDeleteCoupon.setLong(1, couponID);

			int rowAffected = stmtDeleteCoupon.executeUpdate();
			if (rowAffected == 0) {
				throw new SystemMalfunctionException(
						"Something went wrong , Unable to delete coupon with id : " + couponID);

			}

		} catch (SQLException e) {
			throw new SystemMalfunctionException("There was a problem to delete coupon with id :" + couponID);
		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtDeleteCoupon);
		}
	}

	@Override
	public void updateCoupon(Coupon coupon) throws SystemMalfunctionException, CouponNotExistsException {

		Connection connection = null;
		PreparedStatement stmtUpdateCoupon = null;
		long couponId = coupon.getId();

		if (couponId == Coupon.NO_ID) {
			throw new CouponNotExistsException("Unable to update coupon , Invalid id : " + couponId);
		}

		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtUpdateCoupon = connection.prepareStatement(Schema.getUpdateCoupon());
			applyCouponValuesOnStatement(coupon, stmtUpdateCoupon);
			stmtUpdateCoupon.setLong(9, couponId);
			int rowAffected = stmtUpdateCoupon.executeUpdate();

			if (rowAffected == 0) {
				throw new SystemMalfunctionException("Unable to update coupon , something went wrong.");
			}

		} catch (SQLException e) {
			throw new SystemMalfunctionException("There was a problem to update coupon with id : " + couponId);
		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtUpdateCoupon);
		}
	}

	@Override
	public void decrementCouponAmount(long couponID)
			throws SystemMalfunctionException, CouponNotExistsException, zeroCouponAmountException {

		Connection connection = null;
		PreparedStatement stmtDecrementCoupon = null;

		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtDecrementCoupon = connection.prepareStatement(Schema.decrementAmount());
			stmtDecrementCoupon.setLong(1, couponID);
			int rowAffected = stmtDecrementCoupon.executeUpdate();
			if (rowAffected == 0) {
				throw new zeroCouponAmountException("Unable to purchase coupon , Amount = 0 ");

			}
		} catch (SQLException e) {
		System.out.println("Something went wrong , unable to purchase coupon.");

		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtDecrementCoupon);
		}
	}

	@Override
	public Coupon getCoupon(long ID) throws CouponNotExistsException, SystemMalfunctionException {
		Connection connection = null;
		PreparedStatement stmtGetCoupon = null;
		Coupon coupon = null;

		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtGetCoupon = connection.prepareStatement(Schema.getSelectCouponById());
			stmtGetCoupon.setLong(1, ID);
			ResultSet rs = stmtGetCoupon.executeQuery();

			if (rs.first()) {
				coupon = resultSetToCoupon(rs);
				return coupon;

			}
			throw new CouponNotExistsException("Unable to get coupon , invalid id : " + ID);

		} catch (SQLException e) {
			throw new SystemMalfunctionException("Unable to get coupon " + e.getMessage());
		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtGetCoupon);
		}
	}

	@Override
	public Collection<Coupon> getAllCoupons() throws SystemMalfunctionException {

		Connection connection = null;
		Statement stmtGetAllCoupons = null;

		Collection<Coupon> coupons = new ArrayList<>();

		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtGetAllCoupons = connection.createStatement();
			ResultSet rs = stmtGetAllCoupons.executeQuery(Schema.getAllCoupons());

			while (rs.next()) {
				long couponId = rs.getLong(Schema.getColId());
				coupons.add(getCoupon(couponId));
			}

		} catch (Exception e) {
		}

		return coupons;
	}

	@Override
	public Collection<Coupon> getCoupons(CouponCategory category)
			throws SystemMalfunctionException, CouponNotExistsException {
		Connection connection = null;
		PreparedStatement stmtGetCoupondsByCategory = null;
		Collection<Coupon> coupons = new ArrayList<>();

		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtGetCoupondsByCategory = connection.prepareStatement(Schema.selectCouponsByCategory());
			stmtGetCoupondsByCategory.setString(1, category.name());

			ResultSet rs = stmtGetCoupondsByCategory.executeQuery();
			while (rs.next()) {
				coupons.add(getCoupon(rs.getLong(1)));
			}
		} catch (SQLException e) {
			throw new SystemMalfunctionException("Unable to get coupons of that category type : " + category.name());
		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtGetCoupondsByCategory);
		}
		return coupons;
	}

	private static void applyCouponValuesOnStatement(Coupon coupon, PreparedStatement statement) throws SQLException {

		statement.setString(1, coupon.getTitle());
		statement.setDate(2, Date.valueOf(coupon.getStartDate()));
		statement.setDate(3, Date.valueOf(coupon.getEndDate()));
		statement.setInt(4, coupon.getAmount());
		statement.setInt(5, coupon.getCategory());
		statement.setString(6, coupon.getMessage());
		statement.setDouble(7, coupon.getPrice());
		statement.setString(8, coupon.getImage());

	}

	private static long getGeneratedPrimaryKey(PreparedStatement statement) throws SQLException {

		long key = -1;

		ResultSet generatedKeys = statement.getGeneratedKeys();
		if (generatedKeys.next()) {
			key = generatedKeys.getLong(1);
		}
		return key;

	}

	private static Coupon resultSetToCoupon(ResultSet rs) throws SQLException {
		Coupon coupon = new Coupon();

		String colId = Schema.getColId();
		String colTitle = Schema.getColTitle();
		String colStartDate = Schema.getColStartDate();
		String colEndDate = Schema.getColEndDate();
		String colAmount = Schema.getColAmount();
		String colCategory = Schema.getColCategory();
		String colMessege = Schema.getColMessege();
		String colPrice = Schema.getColPrice();
		String colImage = Schema.getColImage();

		coupon.setId(rs.getLong(colId));
		coupon.setTitle(rs.getString(colTitle));
		coupon.setStartDate(rs.getDate(colStartDate).toLocalDate());
		coupon.setEndDate(rs.getDate(colEndDate).toLocalDate());
		coupon.setAmount(rs.getInt(colAmount));
		coupon.setCategory(rs.getInt(colCategory));
		coupon.setMessage(rs.getString(colMessege));
		coupon.setPrice(rs.getDouble(colPrice));
		coupon.setImage(rs.getString(colImage));
		return coupon;
	}
}
