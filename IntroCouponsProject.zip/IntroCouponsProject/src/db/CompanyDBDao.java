package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import common.ConnectionPool;
import common.StatementUtils;
import ex.InvalidLoginException;
import ex.NoSuchCompanyException;
import ex.SystemMalfunctionException;
import model.Company;
import model.Coupon;

public class CompanyDBDao implements CompanyDao {

	public CompanyDBDao()  {
		try {
		creatTable();
	}catch (SystemMalfunctionException e) {
	System.out.println("Should never happand!");
	}}
	
	
	
	@Override
	public void creatTable() throws SystemMalfunctionException {
		Connection connection = null;
		Statement stmtCreateCompanyTable = null;
		Statement stmtCreateCompanyCouponTable = null;

		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtCreateCompanyTable = connection.createStatement();
			stmtCreateCompanyTable.executeUpdate(Schema.getCreateTableCompany());

			stmtCreateCompanyCouponTable = connection.createStatement();
			stmtCreateCompanyCouponTable.executeUpdate(Schema.getCreateTableCompanyCoupon());
		} catch (SQLException e) {
			throw new SystemMalfunctionException("Creating a company table has failed.");
		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtCreateCompanyCouponTable, stmtCreateCompanyTable);
		}
	}

	@Override
	public void createCompany(Company company) throws SystemMalfunctionException {
		Connection connection = null;
		PreparedStatement insertCompany = null;
		
		try {
			connection = ConnectionPool.getInstance().getConnection();
			insertCompany = connection.prepareStatement(Schema.getInsertCompany());
			applyCompanyValuesOnStatement(company, insertCompany);
			insertCompany.executeUpdate();

		} catch (SQLException e) {
			throw new SystemMalfunctionException("Create company has failed!.");
		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(insertCompany);
		}
	}

	@Override
	public void removeCompany(long id) throws SystemMalfunctionException, NoSuchCompanyException {
		Connection connection = null;
		PreparedStatement stmtRemoveCompany = null;
		String message = String.format("Unable to remove company , invalid id:%d", id);
		if (id == Company.NO_ID) {
			throw new NoSuchCompanyException(message);
		}
		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtRemoveCompany = connection.prepareStatement(Schema.getDeleteCompany());
			stmtRemoveCompany.setLong(1, id);

			int rowsAffected = stmtRemoveCompany.executeUpdate();
			if (rowsAffected == 0) {
				throw new NoSuchCompanyException(String.format("No such company with id:%d,", id));
			}
		} catch (SQLException ex) {
			throw new SystemMalfunctionException(message);
		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtRemoveCompany);
		}
	}

	@Override
	public void updateCompany(Company company) throws NoSuchCompanyException, SystemMalfunctionException {
		Connection connection = null;
		PreparedStatement stmtUpdate = null;
		long company_id = company.getId();

		if (company_id == Company.NO_ID) {
			throw new NoSuchCompanyException(
					String.format("Unable to update , company doesnt exists invalid id : %d", company_id));
		}
		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtUpdate = connection.prepareStatement(Schema.getUpdateCompanyById());
			applyCompanyValuesOnStatement(company, stmtUpdate);
			stmtUpdate.setLong(4, company_id);
			int rowAffected = stmtUpdate.executeUpdate();
			if (rowAffected == 0) {
				throw new NoSuchCompanyException(String.format("No such company with id:%d", company_id));
			}

		} catch (SQLException e) {
			throw new SystemMalfunctionException("Unable to update company");
		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtUpdate);
		}
	}

	@Override
	public Company getCompany(long id) throws SystemMalfunctionException, NoSuchCompanyException {
		Connection connection = null;
		PreparedStatement stmtSelectCompanyById = null;
		Company company = null;
		
		if(id == Company.NO_ID) {
			throw new NoSuchCompanyException(String.format("Unable to get company , Invalid id : %d",id));
		}
			try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtSelectCompanyById = connection.prepareStatement(Schema.getSelectCompanyById());
			stmtSelectCompanyById.setLong(1,id);
			ResultSet rs = stmtSelectCompanyById.executeQuery();
			
			if(rs.first()) {
				company = resultSetToCompany(rs);
				company.setCoupons(getCompanyCoupon(id,connection));
				return company;
			}
			
			throw new NoSuchCompanyException("Invalid id , Company not exists.");
			
		} catch (SQLException e) {
			throw new SystemMalfunctionException("Unable to get company, invalid id.");
		}finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtSelectCompanyById);
		}		
	}


	private Set<Coupon> getCompanyCoupon(long id, Connection connection) throws SystemMalfunctionException {
		Set<Coupon> coupons = null;
		PreparedStatement stmtSelectCompanyCoupons = null;
	
		try {
			stmtSelectCompanyCoupons = connection.prepareStatement(Schema.getSelectCompanyCouponInnerJoinById());
			stmtSelectCompanyCoupons.setLong(1, id);
			ResultSet rs = stmtSelectCompanyCoupons.executeQuery();
			coupons = new HashSet<>();
			while (rs.next()) {
				coupons.add(resultSetToCoupon(rs));
			}
			
		} catch (SQLException e) {
			throw new SystemMalfunctionException("No coupons for that compnay id!");
		}finally {
			StatementUtils.closeAll(stmtSelectCompanyCoupons);
		}
		return coupons;
	}

	@Override
	public Collection<Company> getAllCompanies() throws SystemMalfunctionException {
		Connection connection = null;
		Statement stmtGetAllCompanies = null;
		Collection<Company> companies = new ArrayList<>();
		
		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtGetAllCompanies = connection.createStatement();
			
			ResultSet rs = stmtGetAllCompanies.executeQuery(Schema.getSelectAllCompanies());

			while (rs.next()) {
				long companyId = rs.getLong(Schema.getColId());
				companies.add(getCompany(companyId));
			}
			
		}catch (SQLException| NoSuchCompanyException ex) {
			throw new SystemMalfunctionException("Unable to get companies invalid id or there are no active companies.");
			
		}finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtGetAllCompanies);
		}
		
		return companies;
	}

	@Override
	public Collection<Coupon> getCoupons(long companyId) throws SystemMalfunctionException, NoSuchCompanyException {

		Connection connection = ConnectionPool.getInstance().getConnection();
		
		if(companyId == Company.NO_ID) {
			
			throw new NoSuchCompanyException(String.format("Unable to get coupons of that company , Invalid id : %d",companyId));
		}
		try {
			return getCompanyCoupon(companyId, connection);
			
		}finally {
			ConnectionPool.getInstance().returnConnection(connection);
		}}
		
	@Override
	public Company login(String name, String password) throws SystemMalfunctionException, InvalidLoginException {
		
		Connection connection = null;
		PreparedStatement stmtSelectCompanyByNameAndPAssword = null;
		
		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtSelectCompanyByNameAndPAssword = connection.prepareStatement(Schema.SelectCompanyByNameAndPassword());
			stmtSelectCompanyByNameAndPAssword.setString(1,name);
			stmtSelectCompanyByNameAndPAssword.setString(2,password);
			ResultSet rs = stmtSelectCompanyByNameAndPAssword.executeQuery();
			
			if (rs.first()) {
				
				return resultSetToCompany(rs);
			}else {
				throw new InvalidLoginException("Unable to login invalid name/password.");
			}
			
			
		}catch (SQLException e) {
			
			throw new SystemMalfunctionException("Something went wrong while trying to login." + e.getMessage());
		}finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtSelectCompanyByNameAndPAssword);
		}}
		
	private static void applyCompanyValuesOnStatement(Company company, PreparedStatement statement)
			throws SQLException {
		statement.setString(1, company.getName());
		statement.setString(2, company.getPassword());
		statement.setString(3, company.getEmail());
	}

private Company resultSetToCompany(ResultSet rs) throws SQLException {
	Company company = new Company();
	
	company.setId(rs.getLong(1));
	company.setName(rs.getString(2));
	company.setPassword(rs.getString(3));
	company.setEmail(rs.getString(4));
	
	
	return company;
}
private static Coupon resultSetToCoupon(ResultSet rs) throws SQLException {
	Coupon coupon = new Coupon();

	String colId = Schema.getColId();
	String colTitle = Schema.getColTitle();
	String colStartDate = Schema.getColStartDate();
	String colEndDate = Schema.getColEndDate();
	String colAmount = Schema.getColAmount();
	String colCategory = Schema.getColCategory();
	String colMessege = Schema.getColMessege();
	String colPrice = Schema.getColPrice();
	String colImage = Schema.getColImage();

	coupon.setId(rs.getLong(colId));
	coupon.setTitle(rs.getString(colTitle));
	coupon.setStartDate(rs.getDate(colStartDate).toLocalDate());
	coupon.setEndDate(rs.getDate(colEndDate).toLocalDate());
	coupon.setAmount(rs.getInt(colAmount));
	coupon.setCategory(rs.getInt(colCategory));
	coupon.setMessage(rs.getString(colMessege));
	coupon.setPrice(rs.getDouble(colPrice));
	coupon.setImage(rs.getString(colImage));
	return coupon;
}}
