package db;

import java.util.Collection;

import ex.InvalidLoginException;
import ex.NoSuchCompanyException;
import ex.SystemMalfunctionException;
import model.Company;
import model.Coupon;

public interface CompanyDao {

	void creatTable() throws SystemMalfunctionException;

	void createCompany(Company company) throws SystemMalfunctionException;

	void removeCompany(long id) throws SystemMalfunctionException, NoSuchCompanyException;

	void updateCompany(Company company) throws SystemMalfunctionException, NoSuchCompanyException;

	Company getCompany(long id) throws SystemMalfunctionException, NoSuchCompanyException;

	Collection<Company> getAllCompanies() throws SystemMalfunctionException;

	Company login(String name, String password) throws SystemMalfunctionException, InvalidLoginException;

	Collection<Coupon> getCoupons(long couponId) throws SystemMalfunctionException, NoSuchCompanyException;

}
