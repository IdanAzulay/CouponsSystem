package db;

import java.util.Collection;

import ex.CouponNotExistsException;
import ex.SystemMalfunctionException;
import ex.couponAlreadyExistsException;
import ex.zeroCouponAmountException;
import model.Coupon;
import model.CouponCategory;

public interface CouponDAO {

	void createTable() throws SystemMalfunctionException;

	void createCoupon(Coupon coupon, long companyID) throws SystemMalfunctionException, couponAlreadyExistsException;

	void removeCoupon(long couponID) throws SystemMalfunctionException, CouponNotExistsException;

	void updateCoupon(Coupon coupon) throws SystemMalfunctionException, CouponNotExistsException;

	void decrementCouponAmount(long couponID)
			throws SystemMalfunctionException, CouponNotExistsException, zeroCouponAmountException;
	
	Coupon getCoupon(long ID) throws CouponNotExistsException , SystemMalfunctionException;
	
	Collection<Coupon> getAllCoupons() throws SystemMalfunctionException;
	
	Collection<Coupon> getCoupons(CouponCategory category) throws SystemMalfunctionException, CouponNotExistsException;
	

}
