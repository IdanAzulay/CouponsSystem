package db;

import java.util.Collection;

import ex.CouponAllreadyPurchasedException;
import ex.SystemMalfunctionException;
import ex.customerAlreadyExistsException;
import ex.CouponNotExistsException;
import ex.InvalidLoginException;
import ex.NoSuchCustomerException;
import model.Coupon;
import model.Customer;

public interface CustomerDao {

	void createTable() throws SystemMalfunctionException;

	void createCustomer(Customer customer) throws SystemMalfunctionException, customerAlreadyExistsException;

	void removeCustomer(long id) throws SystemMalfunctionException, NoSuchCustomerException;

	void updateCustomer(Customer customer) throws SystemMalfunctionException, NoSuchCustomerException;

	Customer getCustomer(long id) throws SystemMalfunctionException, NoSuchCustomerException;

	Collection<Customer> getAllCustomers() throws SystemMalfunctionException;

	Collection<Coupon> getCoupons(long customerId) throws SystemMalfunctionException;

	void insertCustomerCoupon(long customerId, long couponId) throws SystemMalfunctionException,
			CouponAllreadyPurchasedException, CouponNotExistsException, NoSuchCustomerException;

	Customer login(String name, String password) throws SystemMalfunctionException, InvalidLoginException;

}
