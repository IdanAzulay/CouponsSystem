package db;

public final class Schema {
	/*
	 * Table names
	 */
	private static final String TABLE_NAME_COUPON = "coupon";
	private static final String TABLE_NAME_CUSTOMER = "customer";
	private static final String TABLE_NAME_COMPANY = "company";
	private static final String TABLE_NAME_CUSTOMER_COUPON = "customer_coupon";
	private static final String TABLE_NAME_COMPANY_COUPON = "company_coupon";

	/*
	 * columns
	 */
	private static final String COL_ID = "id";
	private static final String COL_TITLE = "title";
	private static final String COL_START_DATE = "start_date";
	private static final String COL_END_DATE = "end_date";
	private static final String COL_AMOUNT = "amount";
	private static final String COL_CATEGORY = "category";
	private static final String COL_MESSAGE = "message";
	private static final String COL_PRICE = "price";
	private static final String COL_IMAGE = "image";

	private static final String COL_NAME = "name";
	private static final String COL_PASSWORD = "password";
	private static final String COL_EMAIL = "email";

	private static final String COL_CUSTOMER_ID = "customer_id";
	private static final String COL_COUPON_ID = "coupon_id";
	private static final String COL_COMPANY_ID = "company_coupon";

	private static final String CREATE_TABLE_COUPON = "create table if not exists " + TABLE_NAME_COUPON + "(" + COL_ID
			+ " integer primary key auto_increment, " + COL_TITLE + " varchar(100), " + COL_START_DATE + " date, "
			+ COL_END_DATE + " date, " + COL_AMOUNT + " integer, " + COL_CATEGORY + " integer, " + COL_MESSAGE
			+ " varchar(100), " + COL_PRICE + " double, " + COL_IMAGE + " varchar(100));";

	private static final String CREATE_TABLE_CUSTOMER = "create table if not exists " + TABLE_NAME_CUSTOMER + "("
			+ COL_ID + " integer primary key auto_increment, " + COL_NAME + " varchar(100), " + COL_PASSWORD
			+ " varchar(100));";

	private static final String CREATE_TABLE_COMPANY = "create table if not exists " + TABLE_NAME_COMPANY + "(" + COL_ID
			+ " integer primary key auto_increment, " + COL_NAME + " varchar(100), " + COL_PASSWORD + " varchar(100), "
			+ COL_EMAIL + " varchar(100));";

	private static final String CREATE_TABLE_CUSTOMER_COUPON = "create table if not exists "
			+ TABLE_NAME_CUSTOMER_COUPON + " (" + COL_CUSTOMER_ID + " integer, " + COL_COUPON_ID + " integer, "
			+ " foreign key (" + COL_CUSTOMER_ID + ") references " + TABLE_NAME_CUSTOMER + "(" + COL_ID
			+ ") on delete cascade," + " foreign key (" + COL_COUPON_ID + ") references " + TABLE_NAME_COUPON + "("
			+ COL_ID + ") on delete cascade," + " primary key (" + COL_CUSTOMER_ID + "," + COL_COUPON_ID + "));";

	private static final String CREAT_TABLE_COMPANY_COUPON = "create table if not exists " + TABLE_NAME_COMPANY_COUPON + " (" + COL_COMPANY_ID + " integer,"
			+ COL_COUPON_ID + " integer,foreign key (" + COL_COMPANY_ID + ") references " + TABLE_NAME_COMPANY + "("
			+ COL_ID + ") on delete cascade,foreign key (" + COL_COUPON_ID + ") references " + TABLE_NAME_COUPON
			+ "(" + COL_ID + ") on delete cascade,primary key (" + COL_COMPANY_ID + ", " + COL_COUPON_ID + "));";

	public static String getDeleteCompany() {
		return "delete from " + TABLE_NAME_COMPANY + " where " + COL_ID + " = ?;";
	}

	public static String getCreateTableCoupon() {
		return CREATE_TABLE_COUPON;
	}

	public static String getCreateTableCustomer() {
		return CREATE_TABLE_CUSTOMER;
	}

	public static String getCreateTableCompany() {
		return CREATE_TABLE_COMPANY;
	}

	public static String getCreateTableCustomerCoupon() {
		return CREATE_TABLE_CUSTOMER_COUPON;
	}

	public static String getCreateTableCompanyCoupon() {
		return CREAT_TABLE_COMPANY_COUPON;

	}

	public static String getInsertCustomer() {
		return "insert into " + TABLE_NAME_CUSTOMER + "(" + COL_NAME + "," + COL_PASSWORD + ") values(?,?);";
	}

	public static String getInsertCompany() {
		return "insert into " + TABLE_NAME_COMPANY + "(" + COL_NAME + "," + COL_PASSWORD + "," + COL_EMAIL
				+ ") values(?,?,?);";
	}

	public static String getInsertCoupon() {
		return "insert into " + TABLE_NAME_COUPON + "(" + COL_TITLE + ", " + COL_START_DATE + " , "
				+ COL_END_DATE + "," + COL_AMOUNT + " , " + COL_CATEGORY + "," + COL_MESSAGE + "," + COL_PRICE + ", "
				+ COL_IMAGE + ") values(?,?,?,?,?,?,?,?);";
	}

	public static String getInsertCompanyCoupon() {
		return "insert into " + TABLE_NAME_COMPANY_COUPON + "(" + COL_COMPANY_ID + " , " + COL_COUPON_ID
				+ ") values (?,?);";
	}

	public static String getDeleteCustomer() {
		return "delete from " + TABLE_NAME_CUSTOMER + " where " + COL_ID + " = ?;";
	}

	public static String getUpdateCustomerById() {
		return "update " + TABLE_NAME_CUSTOMER + " set " + COL_NAME + "= ?, " + COL_PASSWORD + " = ? where " + COL_ID
				+ " = ?;";
	}

	public static String getSelectCustomerById() {
		return "select * from " + TABLE_NAME_CUSTOMER + " where " + COL_ID + " = ?;";
	}

	public static String getSelectCustomerCouponInnerJoinById() {
		return "select * from " + TABLE_NAME_COUPON + " t1 inner join " + TABLE_NAME_CUSTOMER_COUPON + " t2 on t1."
				+ COL_ID + " = t2." + COL_COUPON_ID + " where t2." + COL_CUSTOMER_ID + " = ?;";
	}

	public static String getSelectIdAllCustomers() {
		return "select " + COL_ID + " from " + TABLE_NAME_CUSTOMER + ";";
	}

	public static String getInsertCustomerCoupon() {
		return "insert into " + TABLE_NAME_CUSTOMER_COUPON + " (" + COL_CUSTOMER_ID + "," + COL_COUPON_ID
				+ ") values (?,?);";
	}

	public static String getSelectCustomerByNameAndPassword() {
		return "select * from " + TABLE_NAME_CUSTOMER + " where " + COL_NAME + " = ? and " + COL_PASSWORD + " = ?;";
	}

	public static String getUpdateCompanyById() {
		return "update " + TABLE_NAME_COMPANY + " set " + COL_NAME + " = ? , " + COL_PASSWORD + " = ? , " + COL_EMAIL
				+ " = ? where " + COL_ID + " = ?;";
	}

	public static String getSelectCompanyCouponInnerJoinById() {
		return "select * from " + TABLE_NAME_COUPON + " t1 inner join " + TABLE_NAME_COMPANY_COUPON + " t2 on t1."
				+ COL_ID + " = t2." + COL_COUPON_ID + " where t2." + COL_COMPANY_ID + " = ?;";
	}

	public static String getSelectCompanyById() {
		return "select * from " + TABLE_NAME_COMPANY + " where " + COL_ID + " = ?;";

	}

	public static String getSelectAllCompanies() {
		return "select " + COL_ID + " from " + TABLE_NAME_COMPANY + ";";
	}

	public static String SelectCompanyByNameAndPassword() {
		return "select * from " + TABLE_NAME_COMPANY + " where " + COL_NAME + " = ? and " + COL_PASSWORD + " = ?;";
	}

	public static String getDeleteCoupon() {
		return "delete  from " + TABLE_NAME_COUPON + " where " + COL_ID + " = ?;";
	}

	public static String getColId() {
		return COL_ID;
	}

	public static String getColTitle() {
		return COL_TITLE;
	}

	public static String getColStartDate() {
		return COL_START_DATE;
	}

	public static String getColEndDate() {
		return COL_END_DATE;
	}

	public static String getColAmount() {
		return COL_AMOUNT;
	}

	public static String getColCategory() {
		return COL_CATEGORY;
	}

	public static String getColMessege() {
		return COL_MESSAGE;
	}

	public static String getColPrice() {
		return COL_PRICE;
	}

	public static String getColImage() {
		return COL_IMAGE;
	}

	public static String getColName() {
		return COL_NAME;
	}

	public static String getColPassword() {
		return COL_PASSWORD;
	}

	public static String getUpdateCoupon() {
		return "update " + TABLE_NAME_COUPON + " set " + COL_TITLE + " = ? , " + COL_START_DATE + " = ? , "
				+ COL_END_DATE + " = ? , " + COL_AMOUNT + " = ? , " + COL_CATEGORY + " = ? , " + COL_MESSAGE + " = ? , "
				+ COL_PRICE + " = ? , " + COL_IMAGE + " = ?  where " + COL_ID + " = ? ; ";
	}

	public static String getAllCoupons() {
		return "select " + COL_ID + " from " + TABLE_NAME_COUPON + "";
	}

	public static String decrementAmount() {
		return "update " + TABLE_NAME_COUPON + " set " + COL_AMOUNT + " = " + COL_AMOUNT + "-1 where " + COL_ID
				+ " = ? and " + COL_AMOUNT + " > 0 ;";
	}

	public static String getSelectCouponById() {
		return "select * from "+TABLE_NAME_COUPON+" where "+COL_ID+" = ?;";
	}

	public static String selectCouponsByCategory() {
		
		return "select * from "+TABLE_NAME_COUPON+" where "+COL_CATEGORY+" = ?;";
	}

}
