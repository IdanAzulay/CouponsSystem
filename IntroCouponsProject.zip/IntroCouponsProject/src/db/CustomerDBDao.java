package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import common.ConnectionPool;
import common.StatementUtils;
import ex.CouponAllreadyPurchasedException;
import ex.CouponNotExistsException;
import ex.InvalidLoginException;
import ex.NoSuchCustomerException;
import ex.SystemMalfunctionException;
import ex.customerAlreadyExistsException;
import model.Coupon;
import model.Customer;

public class CustomerDBDao implements CustomerDao {

	public CustomerDBDao() {
		try {
			createTable();
		} catch (SystemMalfunctionException e) {
			// should never happen.
		}
	}

	@Override
	public void createTable() throws SystemMalfunctionException {
		Statement stmtCreateCustomerTable = null;
		Statement stmtCreateJoinTable = null;
		Connection connection = null;
		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtCreateCustomerTable = connection.createStatement();
			stmtCreateCustomerTable.executeUpdate(Schema.getCreateTableCustomer());

			stmtCreateJoinTable = connection.createStatement();
			stmtCreateCustomerTable.executeUpdate(Schema.getCreateTableCustomerCoupon());
		} catch (SQLException ex) {
			throw new SystemMalfunctionException("There was a problem creating a customer table." + ex.getMessage());
			// finally run just with try block and finally always run after
			// catch
		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtCreateCustomerTable, stmtCreateJoinTable);
		}

	}

	@Override
	public void createCustomer(Customer customer) throws SystemMalfunctionException, customerAlreadyExistsException {
		PreparedStatement stmtInsertCustomer = null;
		Connection connection = null;
		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtInsertCustomer = connection.prepareStatement(Schema.getInsertCustomer());

			applyCustomerValuesOnStatement(customer, stmtInsertCustomer);
			stmtInsertCustomer.executeUpdate();
		} catch (SQLException ex) {
			throw new SystemMalfunctionException("There was a problam creating customer. " + ex.getMessage());
		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtInsertCustomer);
		}

	}

	@Override
	public void removeCustomer(long id) throws SystemMalfunctionException, NoSuchCustomerException {
		PreparedStatement stmtDeleteCustomer = null;
		Connection connection = null;
		if (id == Customer.NO_ID) {
			throw new NoSuchCustomerException("Unable to remove customer with id= " + id);
		}
		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtDeleteCustomer = connection.prepareStatement(Schema.getDeleteCustomer());
			stmtDeleteCustomer.setLong(1, id);
			int rowAffected = stmtDeleteCustomer.executeUpdate();
			if (rowAffected == 0) {
				throw new NoSuchCustomerException("Unable to remove customer with id= " + id);
			}
		} catch (SQLException ex) {
			throw new SystemMalfunctionException("There was problem deleting customer with id = " + id);
		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtDeleteCustomer);

		}
	}

	@Override
	public void updateCustomer(Customer customer) throws SystemMalfunctionException, NoSuchCustomerException {
		Connection connection = null;
		PreparedStatement stmtUpdateCustomer = null;
		long customerId = customer.getId();

		if (customerId == Customer.NO_ID) {
			String msg = String.format("unable to update customer, Invalid = %d", customerId);
			throw new NoSuchCustomerException(msg);
		}
		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtUpdateCustomer = connection.prepareStatement(Schema.getUpdateCustomerById());
			applyCustomerValuesOnStatement(customer, stmtUpdateCustomer);
			stmtUpdateCustomer.setLong(3, customerId);
			int rowsAffected = stmtUpdateCustomer.executeUpdate();
			if (rowsAffected == 0) {
				String msg = String.format(" No such customer, invalid id =  %d", customerId);
				throw new NoSuchCustomerException(msg);
			}
		} catch (SQLException ex) {
			throw new SystemMalfunctionException("Unable to update customer.");
		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtUpdateCustomer);
		}

	}

	@Override
	public Customer getCustomer(long id) throws SystemMalfunctionException, NoSuchCustomerException {
		Connection connection = null;
		PreparedStatement stmtSelectCustomer = null;
		Customer customer = null;
		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtSelectCustomer = connection.prepareStatement(Schema.getSelectCustomerById());
			stmtSelectCustomer.setLong(1, id);
			ResultSet rs = stmtSelectCustomer.executeQuery();
			if (rs.first()) {
				customer = resultSetToCustomer(rs);
				customer.setCoupons(getCustomerCoupons(id, connection));
			} else {
				throw new NoSuchCustomerException(String.format("No such customer. invalid id = %d", id));
			}
		} catch (SQLException ex) {
			throw new SystemMalfunctionException("Unable to getCustomer: " + ex.getMessage());

		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtSelectCustomer);
		}
		return customer;
	}

	@Override
	public Collection<Customer> getAllCustomers() throws SystemMalfunctionException {
		Connection connection = null;
		Statement statement = null;
		Collection<Customer> customers = new ArrayList<>();

		try {
			connection = ConnectionPool.getInstance().getConnection();
			statement = connection.createStatement();

			ResultSet rs = statement.executeQuery(Schema.getSelectIdAllCustomers());

			while (rs.next()) {
				long customerId = rs.getLong(Schema.getColId());
				customers.add(getCustomer(customerId));
			}
		} catch (SQLException | NoSuchCustomerException ex) {
			throw new SystemMalfunctionException("Failed getting all customers: " + ex.getMessage());
		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(statement);
		}

		return customers;
	}

	@Override
	public Collection<Coupon> getCoupons(long customerId) throws SystemMalfunctionException {
		Connection connection = null;

		try {
			connection = ConnectionPool.getInstance().getConnection();
			if (customerId == Customer.NO_ID) {
				throw new NoSuchCustomerException(String.format("No such customer. invalid id = %d", customerId));
			}
			return getCustomerCoupons(customerId, connection);

		} catch (NoSuchCustomerException e) {
			System.out.println("Customer not exists");
		} finally {

			try {
				ConnectionPool.getInstance().returnConnection(connection);
			} catch (SystemMalfunctionException e) {
				// should never happened.
			}
		}
		return Collections.emptyList();
	}

	@Override
	public void insertCustomerCoupon(long customerId, long couponId) throws SystemMalfunctionException,
			CouponAllreadyPurchasedException, CouponNotExistsException, NoSuchCustomerException {
		Connection connection = null;
		PreparedStatement stmtInsertCustomerCoupon = null;

		if (couponId == Coupon.NO_ID) {
			throw new CouponNotExistsException(String.format("No coupon for id = %d", couponId));
		}

		if (customerId == Customer.NO_ID) {
			throw new NoSuchCustomerException(String.format("No customer for id = %d", customerId));
		}

		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtInsertCustomerCoupon = connection.prepareStatement(Schema.getInsertCustomerCoupon());
			stmtInsertCustomerCoupon.setLong(1, customerId);
			stmtInsertCustomerCoupon.setLong(2, couponId);

			stmtInsertCustomerCoupon.executeUpdate();
		} catch (SQLException ex) {
			String msg = String.format("Coupon with id = %d, is already purchased by Customer with id = %d", couponId,
					customerId);
			throw new CouponAllreadyPurchasedException(msg);
		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtInsertCustomerCoupon);
		}

	}

	@Override
	public Customer login(String name, String password) throws SystemMalfunctionException, InvalidLoginException {
		Connection connection = null;
		PreparedStatement stmtSelectCustomer = null;

		try {
			connection = ConnectionPool.getInstance().getConnection();
			stmtSelectCustomer = connection.prepareStatement(Schema.getSelectCustomerByNameAndPassword());
			stmtSelectCustomer.setString(1, name);
			stmtSelectCustomer.setString(2, password);

			ResultSet rs = stmtSelectCustomer.executeQuery();
			if (rs.first()) {
				return resultSetToCustomer(rs);
			} else {
				String msg = String.format("Invalid login for name = %s and password = %s", name, password);
				throw new InvalidLoginException(msg);
			}
		} catch (SQLException ex) {
			throw new SystemMalfunctionException("Something went wrong while trying to login.");
		} finally {
			ConnectionPool.getInstance().returnConnection(connection);
			StatementUtils.closeAll(stmtSelectCustomer);
		}
	}

	private static Set<Coupon> getCustomerCoupons(long id, Connection connection) throws SystemMalfunctionException {
		PreparedStatement selectCustomerCouponStmt = null;
		Set<Coupon> coupons = null;

		try {
			selectCustomerCouponStmt = connection.prepareStatement(Schema.getSelectCustomerCouponInnerJoinById());
			selectCustomerCouponStmt.setLong(1, id);
			ResultSet rs = selectCustomerCouponStmt.executeQuery();
			coupons = new HashSet<>();
			while (rs.next()) {
				coupons.add(resultSetToCoupon(rs));
			}
		} catch (SQLException ex) {
			throw new SystemMalfunctionException("Unable to get customer coupon" + ex.getMessage());
		} finally {
			StatementUtils.closeAll(selectCustomerCouponStmt);
		}
		return coupons;
	}

	private static void applyCustomerValuesOnStatement(Customer customer, PreparedStatement statement)
			throws SQLException {
		statement.setString(1, customer.getName());
		statement.setString(2, customer.getPassword());
	}

	private static Coupon resultSetToCoupon(ResultSet rs) throws SQLException {
		Coupon coupon = new Coupon();

		String colId = Schema.getColId();
		String colTitle = Schema.getColTitle();
		String colStartDate = Schema.getColStartDate();
		String colEndDate = Schema.getColEndDate();
		String colAmount = Schema.getColAmount();
		String colCategory = Schema.getColCategory();
		String colMessege = Schema.getColMessege();
		String colPrice = Schema.getColPrice();
		String colImage = Schema.getColImage();

		coupon.setId(rs.getLong(colId));
		coupon.setTitle(rs.getString(colTitle));
		coupon.setStartDate(rs.getDate(colStartDate).toLocalDate());
		coupon.setEndDate(rs.getDate(colEndDate).toLocalDate());
		coupon.setAmount(rs.getInt(colAmount));
		coupon.setCategory(rs.getInt(colCategory));
		coupon.setMessage(rs.getString(colMessege));
		coupon.setPrice(rs.getDouble(colPrice));
		coupon.setImage(rs.getString(colImage));
		return coupon;
	}

	private Customer resultSetToCustomer(ResultSet rs) throws SQLException {
		Customer customer = new Customer();
		customer.setId(rs.getLong(1));
		customer.setName(rs.getString(2));
		customer.setPassword(rs.getString(3));
		return customer;
	}

}
