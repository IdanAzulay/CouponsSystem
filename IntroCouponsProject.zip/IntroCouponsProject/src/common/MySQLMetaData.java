package common;

public class MySQLMetaData {
	public static final String DRIVER_PATH = "com.mysql.jdbc.Driver";
	public static final String DATABASE_URL = "jdbc:mysql://localhost:3306/world";

}
