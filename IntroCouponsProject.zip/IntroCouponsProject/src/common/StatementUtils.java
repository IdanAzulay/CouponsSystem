package common;

import java.sql.Statement;

import ex.SystemMalfunctionException;

public final  class StatementUtils {
public static void closeAll(Statement...statements ) throws SystemMalfunctionException {
	for (Statement statement : statements) {
		if (statement!= null) {
			try {
				statement.close();
			} catch (Exception e) {
				throw new SystemMalfunctionException("Unable to close statements" + statement);
			}
		}
	}
	
}
}
