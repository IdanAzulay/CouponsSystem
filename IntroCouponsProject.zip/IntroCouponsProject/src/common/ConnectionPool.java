package common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;

import ex.SystemMalfunctionException;

public class ConnectionPool {
	private static ConnectionPool instance;
	private static final int MAX_CONNECTIONS = 10;
	private BlockingDeque<Connection> connections;

	static {
		try {
			Class.forName(MySQLMetaData.DRIVER_PATH);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private ConnectionPool() throws SystemMalfunctionException {
		connections = new LinkedBlockingDeque<>(MAX_CONNECTIONS);
		for (int i = 0; i < MAX_CONNECTIONS; i++) {
			try {
				connections.offer(createConnection());
			} catch (SQLException e) {
				e.printStackTrace();
				throw new SystemMalfunctionException("Unable to offer a connection! ");
			}
		}
	}

	private static Connection createConnection() throws SQLException {
		return DriverManager.getConnection(MySQLMetaData.DATABASE_URL, "root", "idanbenny123");
	}

	public synchronized Connection getConnection() throws SystemMalfunctionException {
		try {
			return connections.take();
		} catch (InterruptedException e) {
			throw new SystemMalfunctionException("Thread interrrupted while waiting for available connection");
		}
	}

	public synchronized void closeAllConnection() throws SystemMalfunctionException {
		Connection connection;
		while ((connection = connections.poll()) != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new SystemMalfunctionException("database access error occures whike trying to close a connection");
			}
		}
	}

	public synchronized static ConnectionPool getInstance() throws SystemMalfunctionException {
		if (instance == null) {
			instance = new ConnectionPool();
		}
		return instance;
	}
	public synchronized void returnConnection(Connection connection) throws SystemMalfunctionException {
		try {
			connections.put(connection);
		} catch (InterruptedException e) {
			throw new SystemMalfunctionException(
					"Thread interrupted while waiting for space to become available for returning a connection");
		}
	}
}
