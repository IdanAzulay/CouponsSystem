package org.jhonbryce.myfirstapp;

import java.util.ArrayList;
import java.util.List;

public class TodoRepository {

private static final List<Todo> TODOS;
	
	static {
		TODOS = new ArrayList<>();
		TODOS.add(new Todo(1, "Title1", "Desc1", true));
		TODOS.add(new Todo(2, "Title2", "Desc2", false));
		TODOS.add(new Todo(3, "Title3", "Desc3", true));
		TODOS.add(new Todo(4, "Title4", "Desc4", false));
	}
	
	public static Todo getTodo(long id) {
		for (Todo todo : TODOS) {
			if (todo.getId() == id) {
				return todo;
			}
		}
		
		return Todo.isEmpty();
	}
	
	public static List<Todo> getAllTodos(){
		return TODOS;
	}


	public static Todo getTodoByTitle(String title) {
		
		for (Todo T : TODOS) {
			if(T.getTitle().equalsIgnoreCase(title)) {
				return T;
			}
		}
		return Todo.isEmpty();
	}

	
	public static Todo getTodoByDescription(String Desc) {
		
		for (Todo T : TODOS) {
			
			if(T.getDescription().toLowerCase().contains(Desc.toLowerCase())) {
				return T;
			}
			
		}
		return Todo.isEmpty();
	}

	public static void insertTodo(Todo todo) {
		TODOS.add(todo);
		
	}
	
	
}

	
	
	
	
	

