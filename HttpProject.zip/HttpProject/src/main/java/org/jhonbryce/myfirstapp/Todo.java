package org.jhonbryce.myfirstapp;

public class Todo {

	
	private static final Todo EMPTY_TODO = new Todo(-1, "NoTitle", "NoDesc", false);
	
	
	private long id;
	private String title;
	private String description;
	private boolean done;
	
	public Todo() {
		
	}
	
	
	
	public Todo(long id , String title , String description , boolean done) {
		
		this.id = id;
		this.title = title;
		this.description = description;
		this.done = done;
	}

	public long getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public String getDescription() {
		return description;
	}

	public boolean isDone() {
		return done;
	}
	
	public static Todo isEmpty() {
		return EMPTY_TODO;
	}
	
	
	

}
