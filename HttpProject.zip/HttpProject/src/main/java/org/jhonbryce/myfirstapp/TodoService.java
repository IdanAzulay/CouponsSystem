package org.jhonbryce.myfirstapp;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import ex.InvalidLoginException;
import ex.SystemMalfunctionException;
import facade.AdminFacade;
import facade.CouponSystem;
import facade.LoginType;
import javassist.bytecode.stackmap.BasicBlock.Catch;
import model.Coupon;
import model.Customer;

@Path("todos")
public class TodoService {

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Todo> getAllTodos() {
		return TodoRepository.getAllTodos();
	}

	@GET
	@Path("todo")
	@Produces(MediaType.APPLICATION_JSON)
	public Todo getTodo(@QueryParam("id") long id) {
		return TodoRepository.getTodo(id);

	}

	@GET
	@Path("todo/ByTitle/{title}")
	@Produces(MediaType.APPLICATION_JSON)
	public Todo getTodoByTitle(@PathParam("title") String title) {
		return TodoRepository.getTodoByTitle(title);
	}

	@GET
	@Path("todo/ByDescription")
	@Produces(MediaType.APPLICATION_JSON)
	public Todo getTodoByDescription(@QueryParam("Desc") String Desc) {

		return TodoRepository.getTodoByDescription(Desc);

	}

//	@POST
//	@Path("insert")
//	@Produces(MediaType.TEXT_PLAIN)
//	public String insertTodo(@QueryParam("id") long id, @QueryParam("title") String title,
//			@QueryParam("desc") String description) {
//	TodoRepository.insertTodo(new Todo(id, title, description, false));
//	return "Todo was inserted succesfully";
//	}
//
//	

	@POST
	@Path("insert")
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_JSON)
	public String insertTodo(Todo todo) {
		TodoRepository.insertTodo(todo);
		return "JSON HAS ADDED";
	}

	@GET
	@Path("getDummyCoupon")
	@Produces(MediaType.APPLICATION_JSON)
	public Coupon getCouponById(){

		return new Coupon();
	}

	@GET
	@Path("getAllCustomers")
	@Produces(MediaType.APPLICATION_JSON)
	public Collection<Customer> getAllCustomers()
	{

		try {
			AdminFacade facade = (AdminFacade) CouponSystem.getInstance().login("admin", "1234", LoginType.ADMIN);
		return facade.getAllCustomers();
			
		}catch (InvalidLoginException | SystemMalfunctionException e) {
			return Collections.emptyList();
		}
		
		
	}

}
